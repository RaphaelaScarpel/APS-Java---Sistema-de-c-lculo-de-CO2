package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	
	 public static Connection getConnection() {
	        // Configurações de conexão
	        String url = "jdbc:mysql://localhost:3306/aps_emissoes_co2";
	        String user = "0000";
	        String password = "0000";
	        
	        Connection connection = null;

	        try {
	            // Registrar o driver JDBC
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            
	            // Estabelecer a conexão
	            connection = DriverManager.getConnection(url, user, password);
	        } catch (ClassNotFoundException e) {
	            System.out.println("Driver JDBC não encontrado.");
	            e.printStackTrace();
	        } catch (SQLException e) {
	            System.out.println("Erro ao conectar ao banco de dados.");
	            e.printStackTrace();
	        }
	        
	        return connection;
	    }
	}