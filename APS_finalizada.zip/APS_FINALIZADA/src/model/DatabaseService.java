package model;

import java.sql.Connection;
import java.sql.SQLException;

public class DatabaseService {

	 public static boolean testConnection() {
	        Connection connection = null;

	        try {
	            connection = DatabaseConnection.getConnection();
	            
	            if (connection != null) {
	                System.out.println("Conexão estabelecida com sucesso!");
	                return true;
	            } else {
	                System.out.println("Falha ao conectar!");
	                return false;
	            }
	        } finally {
	            // Fechar a conexão
	            try {
	                if (connection != null && !connection.isClosed()) {
	                    connection.close();
	                    System.out.println("Conexão fechada com sucesso!");
	                }
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	}