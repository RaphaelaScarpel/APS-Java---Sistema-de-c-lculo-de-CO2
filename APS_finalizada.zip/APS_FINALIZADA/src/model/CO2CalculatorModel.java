package model;

public class CO2CalculatorModel {
    private double total_energia;
    private double total_combustivel;
    private double total_bruto;
    private double vl_compensado;
    private double total_liquido;

    public void calculateCO2Compensation(double vl_eletricidade, double vl_combustivel, double vl_compensado) {
        // CALCULAR EMISSÕES
        total_energia = vl_eletricidade * 0.5 ;
        total_combustivel = vl_combustivel * 2.31 ;
        
        total_bruto = total_energia + total_combustivel;
        
        total_liquido = total_bruto - vl_compensado;
        
    }

    public double getTotalEmissions() {
        return total_bruto;
    }
    
    public double getTotalEletricidadeEmission() {
    	return total_energia;
    }
    
    public double getTotalCombustivelEmission() {
    	return total_combustivel;
    }
    
    public double getTotalLiquido() {
    	return total_liquido;
    }
    
    public double getTotalCompensado() {
    	return vl_compensado;
    }
    
    
}
