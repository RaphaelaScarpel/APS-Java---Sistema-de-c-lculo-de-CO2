package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.CO2CalculatorModel;
import view.CO2CalculatorView;

public class CO2CalculatorController {
    private CO2CalculatorView theView;
    private CO2CalculatorModel theModel;
    
    public CO2CalculatorController(CO2CalculatorView theView, CO2CalculatorModel theModel) {
        this.theView = theView;
        this.theModel = theModel;
        this.theView.addCalculationListener(new CalculateListener());
    }

    class CalculateListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
           //double emissionstextField;
           // try {
           //     emissionstextField = theView.getMonthlyEmissions();
           //     theModel.calculateCO2Compensation(emissionstextField, emissionstextField);
           //     theView.displayTotalEmissions(theModel.getTotalEmissions());
           // } catch (NumberFormatException ex) {
           //     theView.displayErrorMessage("Você precisa inserir um número válido.");
           // }
        }
    }
}
