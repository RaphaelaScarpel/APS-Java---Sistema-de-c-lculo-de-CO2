package controller;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

public class EmissionChart extends ApplicationFrame {

    public EmissionChart(String title) {
        super(title);
        JFreeChart lineChart = ChartFactory.createLineChart(
                "Gráfico de Linhas", // Título do gráfico
                "Categoria", // Rótulo do eixo X
                "Valor", // Rótulo do eixo Y
                createDataset(), // Dados
                PlotOrientation.VERTICAL,
                true, // incluir legenda
                true, // incluir tooltips
                false // incluir URLs
            );

    }

    private DefaultCategoryDataset createDataset() {
    	   DefaultCategoryDataset dataset = new DefaultCategoryDataset();
           dataset.addValue(1.0, "Series1", "Category1");
           dataset.addValue(4.0, "Series1", "Category2");
           dataset.addValue(3.0, "Series1", "Category3");
           dataset.addValue(5.0, "Series1", "Category4");
           return dataset;
    }

    public static void main(String[] args) {
    	EmissionChart chart = new EmissionChart("Exemplo de Gráfico de Linhas");
          chart.pack();
          RefineryUtilities.centerFrameOnScreen(chart);
          chart.setVisible(true);
    }
}