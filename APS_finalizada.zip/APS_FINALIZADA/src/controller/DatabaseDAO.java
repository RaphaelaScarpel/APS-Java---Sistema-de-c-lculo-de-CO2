package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.DatabaseConnection;


public class DatabaseDAO {

    public int insertEmissionData(String year, String month, double totalEmission, double compensationValue, double netTotal) {
        String query = "INSERT INTO emissoes (ano_emissao, mes_emissao, total_bruto_emissao, val_compensado, total_liquido_emissao, data_hora_cadastro) VALUES (?, ?, ?, ?, ?, NOW())";
        int generatedId = -1;
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, year);
            statement.setString(2, month);
            statement.setDouble(3, totalEmission);
            statement.setDouble(4, compensationValue);
            statement.setDouble(5, netTotal);
            statement.executeUpdate();
            
            // Obtém a chave gerada automaticamente
            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    generatedId = generatedKeys.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Tratar exceção, se necessário
        }
        
        return generatedId;
    }
	 
	 public void insertElectricityConsumption(int emissionId, String year, String month, double electricityConsumption) {
	        // Implemente a lógica para inserir os dados na tabela consumo_eletrico
	        // Use um PreparedStatement para evitar SQL injection
	        
	        String query = "INSERT INTO consumo_eletrico (id_emissao, ano_consumo, mes_consumo, consumo_kw) VALUES (?, ?, ?, ?)";
	        
	        try (Connection connection = DatabaseConnection.getConnection();
	             PreparedStatement statement = connection.prepareStatement(query)) {
	            statement.setInt(1, emissionId);
	            statement.setString(2, year);
	            statement.setString(3, month);
	            statement.setDouble(4, electricityConsumption);
	            statement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	            // Tratar exceção, se necessário
	        }
	    }
	 
	 public void insertFuelConsumption(int emissionId, String year, String month, double fuelConsumption) {
	        // Implemente a lógica para inserir os dados na tabela consumo_combustivel
	        // Use um PreparedStatement para evitar SQL injection
	        
	        String query = "INSERT INTO consumo_combustivel (id_emissao, ano_consumo, mes_consumo, consumo_litros) VALUES (?, ?, ?, ?)";
	        
	        try (Connection connection = DatabaseConnection.getConnection();
	             PreparedStatement statement = connection.prepareStatement(query)) {
	            statement.setInt(1, emissionId);
	            statement.setString(2, year);
	            statement.setString(3, month);
	            statement.setDouble(4, fuelConsumption);
	            statement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	            // Tratar exceção, se necessário
	        }
	    }
	    

}
