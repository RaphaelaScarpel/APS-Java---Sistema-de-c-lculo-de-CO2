package view;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import controller.DatabaseDAO;
import model.CO2CalculatorModel;
import model.DatabaseConnection;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import java.awt.event.ActionEvent;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CO2CalculatorView extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField eletricidader_txt;
    private JTextField combustivekl_txt;
    private JComboBox<String> yearCB;
    private JComboBox<String> monthCB;
    private JButton calculateButton;
    private JLabel text_emissões;
    private JLabel text_result;
    private JLabel lbl_bruto;
    private JTextField compensacao_txt;
    private JFreeChart barChart;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CO2CalculatorView frame = new CO2CalculatorView();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public CO2CalculatorView() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1534, 767);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JPanel panel_calculator = new JPanel();
        panel_calculator.setBackground(new Color(214, 214, 214));
        panel_calculator.setBounds(129, 99, 447, 560);
        contentPane.add(panel_calculator);
        panel_calculator.setLayout(null);
        
        JLabel lblTitle = new JLabel("Calculadora de CO2");
        lblTitle.setFont(new Font("Dialog", Font.PLAIN, 20));
        lblTitle.setBounds(127, 10, 182, 35);
        panel_calculator.add(lblTitle);
        
        JLabel yearLabel = new JLabel("Selecione o ano de registro");
        yearLabel.setFont(new Font("Dialog", Font.PLAIN, 16));
        yearLabel.setBounds(23, 82, 198, 23);
        panel_calculator.add(yearLabel);
        
        yearCB = new JComboBox<>();
        yearCB.setFont(new Font("Dialog", Font.PLAIN, 16));
        for (int year = 2024; year >= 2010; year--) {
            yearCB.addItem(String.valueOf(year));
        }
        yearCB.setBounds(246, 80, 152, 26);
        panel_calculator.add(yearCB);
        
        JLabel monthLabel = new JLabel("Selecione o mês de registro ");
        monthLabel.setFont(new Font("Dialog", Font.PLAIN, 16));
        monthLabel.setBounds(23, 127, 210, 23);
        panel_calculator.add(monthLabel);
        
        monthCB = new JComboBox<>();
        monthCB.setFont(new Font("Dialog", Font.PLAIN, 16));
        String[] months = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
        for (String month : months) {
            monthCB.addItem(month);
        }
        monthCB.setBounds(246, 125, 152, 26);
        panel_calculator.add(monthCB);
        
        JLabel emissionsLabel = new JLabel("Informe os KWh de eletricidade consumidos:");
        emissionsLabel.setFont(new Font("Dialog", Font.PLAIN, 16));
        emissionsLabel.setBounds(78, 185, 320, 26);
        panel_calculator.add(emissionsLabel);
        
        eletricidader_txt = new JTextField();
        eletricidader_txt.setFont(new Font("Dialog", Font.PLAIN, 16));
        eletricidader_txt.setBounds(155, 221, 136, 25);
        panel_calculator.add(eletricidader_txt);
        eletricidader_txt.setColumns(10);
        
        JLabel compensationsLabel = new JLabel("Insira o gasto de combustível (litros):");
        compensationsLabel.setFont(new Font("Dialog", Font.PLAIN, 16));
        compensationsLabel.setBounds(93, 257, 282, 31);
        panel_calculator.add(compensationsLabel);
        
        combustivekl_txt = new JTextField();
        combustivekl_txt.setFont(new Font("Dialog", Font.PLAIN, 16));
        combustivekl_txt.setBounds(155, 298, 136, 25);
        panel_calculator.add(combustivekl_txt);
        combustivekl_txt.setColumns(10);
        
        JLabel lbl_bruto = new JLabel("0.0");
        lbl_bruto.setFont(new Font("Dialog", Font.PLAIN, 16));
        lbl_bruto.setBounds(860, 473, 80, 57);
        contentPane.add(lbl_bruto);
        
        JLabel lbl_texto_total_1 = new JLabel("TOTAL LÍQUIDO DE EMISSÕES PARA COMPENSAR: ");
        lbl_texto_total_1.setFont(new Font("Dialog", Font.BOLD, 16));
        lbl_texto_total_1.setBounds(599, 555, 421, 57);
        contentPane.add(lbl_texto_total_1);
        
        JLabel lbl_liq = new JLabel("0.0");
        lbl_liq.setFont(new Font("Dialog", Font.PLAIN, 16));
        lbl_liq.setBounds(1030, 555, 80, 57);
        contentPane.add(lbl_liq);
        
        calculateButton = new JButton("Registrar");
        calculateButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		// Obtém o texto do JTextField e converte para um número
                String texto = eletricidader_txt.getText();
                double vl_eletricidade = Double.parseDouble(texto);
                
                String texto2 = combustivekl_txt.getText();
                double vl_combustivel = Double.parseDouble(texto2);
                
                String texto3 = compensacao_txt.getText();
                double vl_compensado = Double.parseDouble(texto3);
                
                CO2CalculatorModel calculadora = new CO2CalculatorModel();
                calculadora.calculateCO2Compensation(vl_eletricidade, vl_combustivel, vl_compensado );
                
                double totalEmissions = calculadora.getTotalEmissions();
                String resultadoStr = Double.toString(totalEmissions);
                
                double liqTotal = calculadora.getTotalLiquido();
                String resultadoStr2 = Double.toString(liqTotal);
	  
                lbl_bruto.setText(resultadoStr);
                 
                lbl_liq.setText(resultadoStr2);
                
                // REGISTRO NO BANCO DE DADOS
                
                String year = (String) yearCB.getSelectedItem();
                String month = (String) monthCB.getSelectedItem();
                double electricityValue = vl_eletricidade;
                double fuelValue = vl_combustivel;
                double compensationValue = vl_compensado;
                
             // Grava os dados no banco de dados
                DatabaseDAO dao = new DatabaseDAO();
                int emissionId = dao.insertEmissionData(year, month, totalEmissions, compensationValue, liqTotal);

                if (emissionId != -1) {
                    // Grava os dados de consumo elétrico e combustível
                    dao.insertElectricityConsumption(emissionId, year, month, electricityValue);
                    dao.insertFuelConsumption(emissionId, year, month, fuelValue);
                    
                    // Atualiza o JLabel com o valor bruto
                    lbl_bruto.setText(Double.toString(totalEmissions));
                } else {
                    // Tratar falha na obtenção do ID de emissão
                    System.out.println("Falha ao inserir os dados de emissão no banco de dados.");
                }
                
                //ATUALIZA O GRAFICO 
                
                DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                // Cria o dataset inicial
                dataset = createDataset();
                
                // Atualiza o gráfico com o novo dataset
                barChart.getCategoryPlot().setDataset(dataset);
                
                try {
                    Connection connection = DatabaseConnection.getConnection(); // Obtém a conexão com o banco de dados

                    String sql = "SELECT ano_emissao, mes_emissao, sum(total_bruto_emissao) AS total_emission " +
                                 "FROM emissoes " +
                                 "GROUP BY ano_emissao, mes_emissao"+
                                 "ORDER BY ano_emissao, mes_emissao ";
                    PreparedStatement statement = connection.prepareStatement(sql);
                    ResultSet resultSet = statement.executeQuery();

                    // Preenche o dataset com os resultados da consulta
                    while (resultSet.next()) {
                        String ano = resultSet.getString("ano_emissao");
                        String mes = resultSet.getString("mes_emissao");
                        double totalEmission = resultSet.getDouble("total_emission");
                        dataset.addValue(totalEmission, "Emissões", ano + "/" + mes); // Adiciona o valor ao dataset
                    }

                    // Fecha os recursos do banco de dados
                    resultSet.close();
                    statement.close();
                    connection.close();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
                
                
                
        	}
        });
        calculateButton.setFont(new Font("Dialog", Font.PLAIN, 16));
        calculateButton.setBounds(329, 517, 108, 33);
        panel_calculator.add(calculateButton);
        
        JLabel lblImage = new JLabel();
        lblImage.setIcon(new ImageIcon("C:\\Users\\rapha\\OneDrive\\Imagens\\Capturas de tela\\Captura de tela 2024-05-13 165607.png"));
        lblImage.setBounds(200, 500, 62, 50);
        panel_calculator.add(lblImage);
        
        JLabel compensationsLabel_1 = new JLabel("Quantas toneladas de CO2e já foram compensadas?");
        compensationsLabel_1.setFont(new Font("Dialog", Font.PLAIN, 16));
        compensationsLabel_1.setBounds(38, 343, 379, 31);
        panel_calculator.add(compensationsLabel_1);
        
        compensacao_txt = new JTextField();
        compensacao_txt.setFont(new Font("Dialog", Font.PLAIN, 16));
        compensacao_txt.setColumns(10);
        compensacao_txt.setBounds(155, 384, 136, 25);
        panel_calculator.add(compensacao_txt);
        
        JLabel lbl_texto_total = new JLabel("TOTAL BRUTO DE EMISSÕES: ");
        lbl_texto_total.setFont(new Font("Dialog", Font.BOLD, 16));
        lbl_texto_total.setBounds(599, 473, 255, 57);
        contentPane.add(lbl_texto_total);
        
        text_emissões = new JLabel("");
        text_emissões.setFont(new Font("Dialog", Font.PLAIN, 16));
        text_emissões.setBounds(795, 555, 129, 13);
        contentPane.add(text_emissões);
        
        text_result = new JLabel("");
        text_result.setFont(new Font("Dialog", Font.PLAIN, 16));
        text_result.setBounds(1098, 555, 150, 13);
        contentPane.add(text_result);

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        
        try {
            // Obtem a conexão com o banco de dados
            Connection connection = DatabaseConnection.getConnection();

            // Executa a primeira consulta SQL para total de emissões
            String sqlEmissions = "SELECT ano_emissao, mes_emissao, round(sum(total_bruto_emissao), 2) AS total_emission " +
                                  "FROM emissoes " +
                                  "GROUP BY ano_emissao, mes_emissao " +
                                  "ORDER BY ano_emissao, mes_emissao";
            PreparedStatement statementEmissions = connection.prepareStatement(sqlEmissions);
            ResultSet resultSetEmissions = statementEmissions.executeQuery();

            // Preenche o dataset com os resultados da consulta de emissões
            while (resultSetEmissions.next()) {
                String ano = resultSetEmissions.getString("ano_emissao");
                String mes = resultSetEmissions.getString("mes_emissao");
                double totalEmission = resultSetEmissions.getDouble("total_emission");
                dataset.addValue(totalEmission, "Emissões", ano + "/" + mes);
            }

            // Fecha o resultSet e o statement da primeira consulta
            resultSetEmissions.close();
            statementEmissions.close();

            // Executa a segunda consulta SQL para compensação realizada
            String sqlCompensation = "SELECT ano_emissao, mes_emissao, sum(val_compensado) AS total_compensacao_realizada " +
                                     "FROM emissoes " +
                                     "GROUP BY ano_emissao, mes_emissao " +
                                     "ORDER BY ano_emissao, mes_emissao";
            PreparedStatement statementCompensation = connection.prepareStatement(sqlCompensation);
            ResultSet resultSetCompensation = statementCompensation.executeQuery();

            // Preenche o dataset com os resultados da consulta de compensações realizadas
            while (resultSetCompensation.next()) {
                String ano = resultSetCompensation.getString("ano_emissao");
                String mes = resultSetCompensation.getString("mes_emissao");
                double totalCompensation = resultSetCompensation.getDouble("total_compensacao_realizada");
                dataset.addValue(totalCompensation, "Compensação Realizada", ano + "/" + mes);
            }

            // Fecha os recursos do banco de dados
            resultSetCompensation.close();
            statementCompensation.close();

            // Executa a terceira consulta SQL para compensação líquida
            String sqlLiquid = "SELECT ano_emissao, mes_emissao, sum(total_liquido_emissao) AS total_liquido_compensacao " +
                               "FROM emissoes " +
                               "GROUP BY ano_emissao, mes_emissao " +
                               "ORDER BY ano_emissao, mes_emissao";
            PreparedStatement statementLiquid = connection.prepareStatement(sqlLiquid);
            ResultSet resultSetLiquid = statementLiquid.executeQuery();

            // Preenche o dataset com os resultados da consulta de compensações líquidas
            while (resultSetLiquid.next()) {
                String ano = resultSetLiquid.getString("ano_emissao");
                String mes = resultSetLiquid.getString("mes_emissao");
                double totalLiqCompensation = resultSetLiquid.getDouble("total_liquido_compensacao");
                dataset.addValue(totalLiqCompensation, "Compensações Restantes", ano + "/" + mes);
            }

            // Fecha os recursos do banco de dados
            resultSetLiquid.close();
            statementLiquid.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }



        barChart = ChartFactory.createLineChart(
        		  "Emissões de CO2 e Compensações", // Título do gráfico
        	        "Data", // Rótulo do eixo X
        	        "Total (Emissões e Compensações)", // Rótulo do eixo Y
        	        dataset, // Dados
        	        PlotOrientation.VERTICAL,
        	        true, // incluir legenda
        	        true, // incluir tooltips
        	        false // incluir URLs
        );
        
        // Criando o painel de gráfico
        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setBounds(649, 99, 691, 364);
        contentPane.add(chartPanel);
        
        JLabel fundo = new JLabel("New label");
        fundo.setIcon(new ImageIcon("C:\\Users\\rapha\\Downloads\\Cópia de Sustentabilidade.png"));
        fundo.setBounds(0, 0, 1560, 943);
        contentPane.add(fundo);
        
        
       




        
    }
    
    private DefaultCategoryDataset createDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try {
            // Obtem a conexão com o banco de dados
            Connection connection = DatabaseConnection.getConnection();

            // Executa a primeira consulta SQL para total de emissões
            String sqlEmissions = "SELECT ano_emissao, mes_emissao, round(sum(total_bruto_emissao), 2) AS total_emission " +
                                  "FROM emissoes " +
                                  "GROUP BY ano_emissao, mes_emissao " +
                                  "ORDER BY ano_emissao, mes_emissao";
            PreparedStatement statementEmissions = connection.prepareStatement(sqlEmissions);
            ResultSet resultSetEmissions = statementEmissions.executeQuery();

            // Preenche o dataset com os resultados da consulta de emissões
            while (resultSetEmissions.next()) {
                String ano = resultSetEmissions.getString("ano_emissao");
                String mes = resultSetEmissions.getString("mes_emissao");
                double totalEmission = resultSetEmissions.getDouble("total_emission");
                dataset.addValue(totalEmission, "Emissões", ano + "/" + mes);
            }

            // Fecha o resultSet e o statement da primeira consulta
            resultSetEmissions.close();
            statementEmissions.close();

            // Executa a segunda consulta SQL para compensação realizada
            String sqlCompensation = "SELECT ano_emissao, mes_emissao, sum(val_compensado) AS total_compensacao_realizada " +
                                     "FROM emissoes " +
                                     "GROUP BY ano_emissao, mes_emissao " +
                                     "ORDER BY ano_emissao, mes_emissao";
            PreparedStatement statementCompensation = connection.prepareStatement(sqlCompensation);
            ResultSet resultSetCompensation = statementCompensation.executeQuery();

            // Preenche o dataset com os resultados da consulta de compensações realizadas
            while (resultSetCompensation.next()) {
                String ano = resultSetCompensation.getString("ano_emissao");
                String mes = resultSetCompensation.getString("mes_emissao");
                double totalCompensation = resultSetCompensation.getDouble("total_compensacao_realizada");
                dataset.addValue(totalCompensation, "Compensação Realizada", ano + "/" + mes);
            }

            // Fecha os recursos do banco de dados
            resultSetCompensation.close();
            statementCompensation.close();

            // Executa a terceira consulta SQL para compensação líquida
            String sqlLiquid = "SELECT ano_emissao, mes_emissao, sum(total_liquido_emissao) AS total_liquido_compensacao " +
                               "FROM emissoes " +
                               "GROUP BY ano_emissao, mes_emissao " +
                               "ORDER BY ano_emissao, mes_emissao";
            PreparedStatement statementLiquid = connection.prepareStatement(sqlLiquid);
            ResultSet resultSetLiquid = statementLiquid.executeQuery();

            // Preenche o dataset com os resultados da consulta de compensações líquidas
            while (resultSetLiquid.next()) {
                String ano = resultSetLiquid.getString("ano_emissao");
                String mes = resultSetLiquid.getString("mes_emissao");
                double totalLiqCompensation = resultSetLiquid.getDouble("total_liquido_compensacao");
                dataset.addValue(totalLiqCompensation, "Compensações Restantes", ano + "/" + mes);
            }

            // Fecha os recursos do banco de dados
            resultSetLiquid.close();
            statementLiquid.close();
            connection.close();
          } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return dataset;
    }


    public String getSelectedYear() {
        return (String) yearCB.getSelectedItem();
    }

    public String getSelectedMonth() {
        return (String) monthCB.getSelectedItem();
    }

    public double getMonthlyEmissions() {
        return Double.parseDouble(eletricidader_txt.getText());
    }

    public double getMonthlyCompensations() {
        return Double.parseDouble(combustivekl_txt.getText());
    }

    public void displayTotalEmissions(double totalEmissions) {
        text_emissões.setText(String.valueOf(totalEmissions));
        System.out.print("Teste");
        text_result.setText(String.valueOf(totalEmissions * 2)); // Supondo que o resultado da compensação seja duas vezes o total de emissões.
        JOptionPane.showMessageDialog(this, "Emissões totais: " + totalEmissions, "Resultado", JOptionPane.INFORMATION_MESSAGE);
    }

    public void displayErrorMessage(String errorMessage) {
        JOptionPane.showMessageDialog(this, errorMessage, "Erro", JOptionPane.ERROR_MESSAGE);
    }

    public void addCalculationListener(ActionListener listenForCalcButton) {
        calculateButton.addActionListener(listenForCalcButton);
    }
}
