import model.DatabaseService;
import view.CO2CalculatorView;

public class Main {

	public static void main(String[] args) {
		 CO2CalculatorView.main(args);
		 
		 // Chama o teste de conexão
		 boolean isConnected = DatabaseService.testConnection();
	        
	        if (isConnected) {
	            // Outras inicializações do aplicativo...
	            System.out.println("Conexão estabelecida! Inicializando o aplicativo...");
	        } else {
	            // Tratar falha na conexão...
	            System.out.println("Falha ao estabelecer a conexão com o banco de dados.");
	        }
	    	
	       
	}
}

